
import matplotlib.pyplot as plt 
x=range(0,10) 
y1=[10,13,5,40,30,60,70,12,55,25] 
y2=[5,8,0,30,20,40,50,10,40,15] 
plt.plot(x,y1,label='Frist line',linewidth=3,color='r',marker='o', 
markerfacecolor='blue',markersize=12) 
plt.plot(x,y2,label='second line') 
plt.xlabel('Index') 
plt.ylabel('Value') 
plt.title('Title') 
plt.legend(loc='upper left') 
plt.show() 