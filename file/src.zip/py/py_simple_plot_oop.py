
import matplotlib.pyplot as plt 
x=range(0,10) 
y1=[10,13,5,40,30,60,70,12,55,25] 
y2=[5,8,0,30,20,40,50,10,40,15] 
fig= plt.figure()
ax = plt.gca()
ax.plot(x,y1,label='Frist line',linewidth=3,color='r',marker='o', 
markerfacecolor='blue',markersize=12) 
ax.plot(x,y2,label='second line') 
ax.set_xlabel('Index') 
ax.set_ylabel('Value') 
ax.set_title('Title') 
ax.legend(loc='upper left') 
plt.show() 