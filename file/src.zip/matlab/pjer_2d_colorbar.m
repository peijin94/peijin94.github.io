
t0=rand(1e4,1)*2*pi;
R0=rand(1e4,1);

x=R0.*sin(t0);
y=R0.*cos(t0);

Z1=R0;
Z2=x+y;

H = Z1/2;
S = ones(size(Z1));
V = (Z2-min(Z2))./max(Z2-min(Z2));

scatter(x,y,3,hsv2rgb([H,S,V]))
axis equal
axis tight

figure
colorplate_hsv=zeros(400,200,3);

%H
colorplate_hsv(:,:,1)=repmat(linspace(0,1,400)'/2,1,200);
%S
colorplate_hsv(:,:,2)=ones(400,200);
%V
colorplate_hsv(:,:,3)=repmat(linspace(0,1,200),400,1);


imshow(hsv2rgb(colorplate_hsv))
axis on
xticks([1 200/2 200])
xticklabels({'0','0.5','1'})
xlabel('x')

