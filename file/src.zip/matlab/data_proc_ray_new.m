load meta.mat

[twidth,ttrail,tlead] = fwhm(meta.OUT.TBINS,meta.OUT.TPDF/max(meta.OUT.TPDF));

figure(2)

subplot(211)
plot(meta.OUT.TBINS,meta.OUT.TPDF/max(meta.OUT.TPDF),'color','k')
xlim([0.8,2])
subplot(212)
hold on
h1  = plot(meta.OUT.TBINS,meta.OUT.XS_TIME,'color','r');
errorbar(meta.OUT.TBINS+meta.OUT.DTBIN/2, meta.OUT.XS_TIME, ...
    meta.OUT.ERR_XS_TIME,'r')
h2  = plot(meta.OUT.TBINS,meta.OUT.YS_TIME,'color','b');
errorbar(meta.OUT.TBINS+meta.OUT.DTBIN/2, meta.OUT.YS_TIME, ...
    meta.OUT.ERR_YS_TIME,'b')
legend([h1,h2],{'x','y'});

xlim([0.8,2])


figure(1)
ax1 = axes('position',[0.16,0.1,0.8,0.5]);
rectangle('Position',[tlead,0,twidth,2],'facecolor',[.9,.9,.9],'edgecolor','none')
hold on
h1  = stairs(meta.OUT.TBINS,meta.OUT.XS_TIME,'color','r','linewidth',1);
errorbar(meta.OUT.TBINS+meta.OUT.DTBIN/2, meta.OUT.XS_TIME, ...
    meta.OUT.ERR_XS_TIME,'r.','linewidth',1)

h2  = stairs(meta.OUT.TBINS,meta.OUT.YS_TIME,'color','b','linewidth',1);
errorbar(meta.OUT.TBINS+meta.OUT.DTBIN/2, meta.OUT.YS_TIME, ...
    meta.OUT.ERR_YS_TIME,'b.','linewidth',1)

lgd=legend([h1,h2],{'x','y'});
set(lgd,'Location', 'northwest')
yticks([0,0.5,1,1.5])
box('on');
xlim([0.8,2])
ylim([0,2])
set(gca, 'Layer', 'top')
 
xlabel('Time [s]','fontsize',11)
ylabel('FWHM Size [R_{sun}]','fontsize',11)
 
 
 
ax2 = axes('position',[0.16,0.6,0.8,0.3]);
rectangle('Position',[tlead,0,twidth,2],'facecolor',[.9,.9,.9],'edgecolor','none')
hold on
stairs(meta.OUT.TBINS,meta.OUT.TPDF/max(meta.OUT.TPDF),'color','k','linewidth',1)
box('on');
xticks([])
xlim([0.8,2])
ylim([0,1.2])
 set(gca, 'Layer', 'top')
 
ylabel('Normalized Flux','fontsize',11)
 
 
 set(gcf,'position',[400 200 350 420])
 
 set(gcf, 'PaperPosition', [0 0 8 10]); 
  set(gcf, 'PaperSize', [8 10]); 
print(gcf,'simulation_fwhm.eps','-depsc')
saveas(gcf,'simulation_fwhm.pdf')

