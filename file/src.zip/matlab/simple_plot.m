% ���
clear;
close all;
clc;

xx = 0:0.1:2*pi;
yy = 1+sin(xx);

%stem(xx,yy)

Z = peaks(32);


imagesc(Z)